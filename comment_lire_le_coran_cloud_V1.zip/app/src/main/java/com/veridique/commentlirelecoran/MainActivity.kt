package com.veridique.commentlirelecoran

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var tts: TextToSpeech
    private val letters = listOf("ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { tts.language = Locale("ar") }
        showHome()
    }

    private fun base(title:String): LinearLayout {
        val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(28,28,28,28)
        l.setBackgroundColor(Color.rgb(247,243,232))
        val h=TextView(this); h.text=title; h.textSize=28f; h.setTextColor(Color.rgb(23,107,82)); h.gravity=Gravity.CENTER; h.setPadding(0,20,0,30)
        l.addView(h)
        return l
    }
    private fun btn(text:String, action:()->Unit):Button {
        val b=Button(this); b.text=text; b.setOnClickListener{action()}; return b
    }
    private fun showHome(){
        val l=base("COMMENT LIRE LE CORAN")
        val sub=TextView(this); sub.text="Apprenez à lire l’écriture arabe étape par étape."; sub.textSize=18f; sub.gravity=Gravity.CENTER
        l.addView(sub)
        l.addView(btn("🚀 COMMENCER L’APPRENTISSAGE"){showLetters()})
        l.addView(btn("🎯 EXERCICES"){showExercise()})
        l.addView(btn("📊 MA PROGRESSION"){showProgress()})
        l.addView(btn("🔐 PREMIUM — 2 000 F CFA"){showPremium()})
        l.addView(btn("👤 PROFIL"){showProfile()})
        setContentView(l)
    }
    private fun showLetters(){
        val l=base("Les 28 lettres arabes")
        val grid=GridLayout(this); grid.columnCount=4
        letters.forEachIndexed{ i,ch ->
            val b=Button(this); b.text=ch; b.textSize=28f
            b.setOnClickListener{showLesson(ch,i)}
            grid.addView(b, GridLayout.LayoutParams().apply{width=0; height=120; columnSpec=GridLayout.spec(i%4,1f)})
        }
        l.addView(grid)
        l.addView(btn("← Accueil"){showHome()}); setContentView(l)
    }
    private fun showLesson(ch:String, index:Int){
        val l=base("Leçon — $ch")
        val big=TextView(this); big.text="$ch\n\n🔊"; big.textSize=60f; big.gravity=Gravity.CENTER
        l.addView(big)
        val info=TextView(this); info.text="Forme début : ${if(index==0) ch else ch+"ـ"}\nForme milieu : ـ${ch}ـ\nForme fin : ـ$ch"; info.textSize=25f; info.gravity=Gravity.CENTER
        l.addView(info)
        l.addView(btn("🔊 ÉCOUTER"){tts.speak(ch,TextToSpeech.QUEUE_FLUSH,null,"letter")})
        l.addView(btn("🎯 FAIRE L’EXERCICE"){showExercise()})
        l.addView(btn("← Lettres"){showLetters()}); setContentView(l)
    }
    private fun showExercise(){
        val l=base("Exercice")
        val q=TextView(this); q.text="Quelle est la lettre « Bā » ?"; q.textSize=24f; q.gravity=Gravity.CENTER
        l.addView(q)
        listOf("ت","ب","ث").forEach{ch-> l.addView(btn(ch){Toast.makeText(this, if(ch=="ب") "✅ Excellent ! Continue comme ça 👏" else "❌ Essaie encore.", Toast.LENGTH_SHORT).show()})}
        l.addView(btn("← Accueil"){showHome()}); setContentView(l)
    }
    private fun showProgress(){
        val l=base("Ma progression"); val t=TextView(this); t.text="📖 Lettres : 0 / 28\n🔤 Formes : 0 / 28\n🧩 Assemblage : 0 / 20\n\n🔥 Continue ton apprentissage !"; t.textSize=22f; l.addView(t)
        l.addView(btn("← Accueil"){showHome()}); setContentView(l)
    }
    private fun showPremium(){
        val l=base("Débloquer Premium"); val t=TextView(this); t.text="Accédez aux leçons Premium.\n\nPrix : 2 000 F CFA\n\nEntrez votre code d’accès."; t.textSize=20f; l.addView(t)
        val input=EditText(this); input.hint="Code Premium"; l.addView(input)
        l.addView(btn("🔑 VALIDER LE CODE"){Toast.makeText(this,"Code reçu : connexion au serveur à configurer.",Toast.LENGTH_LONG).show()})
        l.addView(btn("← Accueil"){showHome()}); setContentView(l)
    }
    private fun showProfile(){
        val l=base("Mon profil"); val t=TextView(this); t.text="👤 Mon profil\n\n📊 Ma progression\n🏆 Mes réussites\n🔐 Mon accès Premium\n\n🇲🇱 LE VERIDIQUE A-Z"; t.textSize=21f; l.addView(t)
        l.addView(btn("← Accueil"){showHome()}); setContentView(l)
    }
    override fun onDestroy(){ tts.shutdown(); super.onDestroy() }
}
