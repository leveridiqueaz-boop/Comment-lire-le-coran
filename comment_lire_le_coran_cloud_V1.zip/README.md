# Comment lire le Coran — Android

Projet Android/Kotlin prêt pour une compilation cloud via GitHub Actions.

Fonctions de démonstration : 28 lettres arabes, formes début/milieu/fin, prononciation TTS, exercices, assemblage, progression, Premium 2 000 F CFA et profil.

Pour compiler sans ordinateur, suivre `README_TELEPHONE.md`.

Le workflow `.github/workflows/build-apk.yml` génère automatiquement `app-debug.apk`.
