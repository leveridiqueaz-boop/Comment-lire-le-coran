# Compiler l'APK depuis un téléphone Android

Ce projet est préparé pour être compilé automatiquement dans GitHub Actions, sans ordinateur.

## Méthode

1. Crée ou ouvre un compte GitHub sur ton téléphone.
2. Crée un nouveau dépôt, par exemple `comment-lire-le-coran`.
3. Télécharge ce ZIP sur ton téléphone et décompresse-le.
4. Dans GitHub, utilise **Add file > Upload files** et envoie **tout le contenu du dossier** (pas le ZIP).
5. Valide les fichiers dans la branche `main`.
6. Ouvre l'onglet **Actions** du dépôt.
7. Choisis **Build APK** puis **Run workflow**.
8. Attends que le travail soit terminé avec une coche verte.
9. Ouvre le workflow terminé et récupère l'artefact **CommentLireLeCoran-debug**.
10. Décompresse l'artefact : il contient `app-debug.apk`.
11. Ouvre l'APK sur ton téléphone pour l'installer.

## Important

- Cette méthode produit une APK **debug de test**, pas une version Play Store signée.
- Les fonctions serveur/paiement réel ne sont pas encore branchées.
- Ne publie pas de clés secrètes ou identifiants de paiement dans le dépôt GitHub.
